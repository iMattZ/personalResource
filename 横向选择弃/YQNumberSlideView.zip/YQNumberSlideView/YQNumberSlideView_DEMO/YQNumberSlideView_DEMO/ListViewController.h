//
//  ListViewController.h
//  MessageHomeDemo
//
//  Created by Mac on 2019/7/5.
//  Copyright © 2019 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JXCategoryListContainerView.h"
NS_ASSUME_NONNULL_BEGIN

@interface ListViewController : UIViewController<JXCategoryListContentViewDelegate>

@end

NS_ASSUME_NONNULL_END
