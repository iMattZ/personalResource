//
//  ViewController.m
//  YQNumberSlideView_DEMO
//
//  Created by problemchild on 2017/5/13.
//  Copyright © 2017年 freakyyang. All rights reserved.
//

#import "ViewController.h"
#import "YQNumberSlideView.h"
#define WindowsSize [UIScreen mainScreen].bounds.size

@interface ViewController ()<YQNumberSlideViewDelegate,UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UILabel *lab;

@property(nonatomic,strong) YQNumberSlideView *slideView;

@property (nonatomic, strong) UITableView *tableView;


@property (nonatomic, assign) int currentNum;


@end

@implementation ViewController

- (UITableView *)tableView {
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 200, 375, 300) style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
 
    [self.view addSubview:self.tableView];
    
    
    
    self.slideView = [[YQNumberSlideView alloc]initWithFrame:CGRectMake(0,
                                                                        50,
                                                                        [UIScreen mainScreen].bounds.size.width-0,
                                                                        100)];
    //设置一个背景色，以便查看范围
    self.slideView.backgroundColor = [UIColor colorWithWhite:0.931 alpha:1.000];
    
//    [self.slideView setLableCount:20];
    //监控代理
    self.slideView.delegate = self;
    [self.view addSubview:self.slideView];
    
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 60, 88)];
    view.layer.borderColor = [UIColor orangeColor].CGColor;
    view.layer.borderWidth = 5;
    [self.view addSubview:view];
    view.center = self.slideView.center;
    
    
    //以下为自定义显示的方法
     //设置数量
     [self.slideView setLableCount:8];
     [self.slideView setShowArray:@[
     @"小明",
     @"小红",
     @"小方",
     @"小亮",
     @"小华",
     @"小坏",
     @"小丑",
     @"小帅",
     ]];
     //设置一下宽度
     self.slideView.lableWidth = 60;
     //显示
     [self.slideView show];
//     */
    
    //
     //彩色模式
//     [self.slideView DiffrentColorModeWithMainColorR:0.154 G:1.000 B:0.063
//                                           SecColorR:0.281 G:0.772 B:0.970];
    
//     [self.slideView setLableCount:20];
     //监控代理
//     self.slideView.delegate = self;
//     [self.slideView show];
    
    
    [self.slideView scrollTo:6];
    
}

- (IBAction)GoLeft:(id)sender {
    [self.slideView pre];
}
- (IBAction)goRight:(id)sender {
    [self.slideView next];
}

- (void)YQSlideViewDidChangeIndex:(int)count
{
    self.lab.text = [NSString stringWithFormat:@"当前页：%d",count+1];
    self.currentNum = count+1;
    [self.tableView reloadData];
}

- (void)YQSlideViewDidTouchIndex:(int)count
{
    [self.slideView scrollTo:count];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 10;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellid"];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%d，组%ld组，%ld行",self.currentNum,(long)indexPath.section,(long)indexPath.row];
    return cell;
}


@end
