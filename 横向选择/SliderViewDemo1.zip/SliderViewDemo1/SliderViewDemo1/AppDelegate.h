//
//  AppDelegate.h
//  SliderViewDemo1
//
//  Created by Mac on 2019/7/18.
//  Copyright © 2019 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

