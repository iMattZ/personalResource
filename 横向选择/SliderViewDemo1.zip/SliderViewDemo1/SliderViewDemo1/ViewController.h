//
//  ViewController.h
//  SliderViewDemo1
//
//  Created by Mac on 2019/7/18.
//  Copyright © 2019 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

