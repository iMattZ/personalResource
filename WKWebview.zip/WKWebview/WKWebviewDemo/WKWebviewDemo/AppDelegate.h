//
//  AppDelegate.h
//  WKWebviewDemo
//
//  Created by Mac on 2019/8/2.
//  Copyright © 2019 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

