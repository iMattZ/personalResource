//
//  MyCustomURLProtocol.h
//  CCCC
//
//  Created by usee on 2018/1/2.
//  Copyright © 2018年 tax. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCustomURLProtocol : NSURLProtocol
@end
