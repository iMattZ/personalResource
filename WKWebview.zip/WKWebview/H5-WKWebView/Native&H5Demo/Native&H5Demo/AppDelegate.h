//
//  AppDelegate.h
//  Native&H5Demo
//
//  Created by YaoJiaQi on 2018/2/12.
//  Copyright © 2018年 YaoJiaQi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

